import os
import time
import pandas as pd
import sqlite3
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

# 1. Create a database and a table 
def create_database():
    conn = sqlite3.connect("sales.db")  # Create or open database
    cur = conn.cursor()

    # Create a sales table
    cur.execute('''
        CREATE TABLE IF NOT EXISTS sales (
            ID INTEGER,
            Date TEXT,
            Product TEXT,
            Quantity INTEGER,
            Price REAL
        )
    ''')

    conn.commit()
    conn.close()

# 2. Read a CSV file and insert into database
def insert_csv_into_db(file_path):
    try:
        # Read the file
        data = pd.read_csv(file_path)

        # Check required columns
        if {"ID", "Date", "Product", "Quantity", "Price"}.issubset(data.columns):
            conn = sqlite3.connect("sales.db")
            data.to_sql("sales", conn, if_exists="append", index=False)
            conn.close()
            print(f" File uploaded to database: {file_path}")
        else:
            print(f" File skipped (missing columns): {file_path}")

    except Exception as e:
        print(f" Error reading file: {file_path}")
        print(e)

# 3. Watch the folder for new .csv files
class FileWatcher(FileSystemEventHandler):
    def on_created(self, event):
        if event.src_path.endswith(".csv"):
            time.sleep(1)  # wait for file to fully save
            insert_csv_into_db(event.src_path)

# 4. Start watching the folder
def start_watching(folder_name="uploads"):
    print(f" Watching folder: {folder_name}")
    os.makedirs(folder_name, exist_ok=True)  # create folder if it doesn't exist

    event_handler = FileWatcher()
    observer = Observer()
    observer.schedule(event_handler, path=folder_name, recursive=False)
    observer.start()

    try:
        while True:
            time.sleep(1) 
    except KeyboardInterrupt:
        observer.stop()
        print(" Stopped watching.")
    observer.join()

# 5. Run all steps
if __name__ == "__main__":
    create_database()
    start_watching()
