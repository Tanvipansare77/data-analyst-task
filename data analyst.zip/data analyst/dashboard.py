import pandas as pd
import plotly.express as px
import dash
from dash import dcc, html, Input, Output

# Step 1: Load and prepare the data
try:
    df = pd.read_csv("sales_data.csv")
    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    df = df.dropna(subset=["Date"]) 

    # Rename 'Quantity' to 'Units_Sold' for consistency
    df.rename(columns={"Quantity": "Units_Sold"}, inplace=True)

    # Add Revenue column
    df["Revenue"] = df["Units_Sold"] * df["Price"]

except Exception as e:
    print("Error loading CSV:", e)
    df = pd.DataFrame(columns=["Date", "Product", "Units_Sold", "Price", "Revenue"])

# Step 2: Create the Dash app
app = dash.Dash(__name__)

# Step 3: App layout
app.layout = html.Div([
    html.H1(" Simple Sales Dashboard", style={'textAlign': 'center'}),

    html.Label("Select Product:"),
    dcc.Dropdown(
        id="product-dropdown",
        options=[{"label": p, "value": p} for p in df["Product"].unique()],
        value=df["Product"].unique()[0] if not df.empty else None
    ),

    dcc.Graph(id="revenue-graph"),
    dcc.Graph(id="units-graph")
])

# Step 4: Callback to update graphs
@app.callback(
    [Output("revenue-graph", "figure"),
     Output("units-graph", "figure")],
    [Input("product-dropdown", "value")]
)
def update_graphs(selected_product):
    if selected_product is None or df.empty:
        return {}, {}

    filtered_df = df[df["Product"] == selected_product]

    # Line chart for revenue
    fig1 = px.line(
        filtered_df,
        x="Date",
        y="Revenue",
        title=f"{selected_product} - Revenue Over Time"
    )

    # Bar chart for units sold
    fig2 = px.bar(
        filtered_df,
        x="Date",
        y="Units_Sold",
        title=f"{selected_product} - Units Sold Over Time"
    )

    return fig1, fig2


# Step 5: Run the Dash server
if __name__ == "__main__":
    app.run(debug=True)
