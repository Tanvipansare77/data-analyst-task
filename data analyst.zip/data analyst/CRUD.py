import pandas as pd

file = "sales_data.csv" 
# 1.create
def add_sale():
    id = int(input("Enter ID: "))
    date = input("Enter Date (YYYY-MM-DD): ")
    product = input("Enter Product Name: ")
    quantity = int(input("Enter Quantity: "))
    price = float(input("Enter Price: "))

    new_data = pd.DataFrame([{
        "ID": id,
        "Date": date,
        "Product": product,
        "Quantity": quantity,
        "Price": price
    }])

 
    data = pd.read_csv(file)
    data = pd.concat([data, new_data], ignore_index=True)
    data.to_csv(file, index=False)
    print("Sale added successfully!\n")

# 2. read
def show_sales():
    product_name = input("Enter product name to search: ")
    data = pd.read_csv(file)

    result = data[data["Product"].str.lower() == product_name.lower()]

    print("\n Matching sales:")
    if not result.empty:
        print(result)
    else:
        print("No records found.\n")

# 3. Update 
def update_sale():
    id_to_update = int(input("Enter ID to update: "))
    data = pd.read_csv(file)

    if id_to_update in data["ID"].values:
        new_quantity = int(input("Enter new quantity: "))
        new_price = float(input("Enter new price: "))

        # Update the row with matching ID
        data.loc[data["ID"] == id_to_update, "Quantity"] = new_quantity
        data.loc[data["ID"] == id_to_update, "Price"] = new_price

        data.to_csv(file, index=False)
        print(" Sale updated successfully!\n")
    else:
        print(" ID not found.\n")

# 4. Delete sale by ID 
def delete_sale():
    id_to_delete = int(input("Enter ID to delete: "))
    data = pd.read_csv(file)

    if id_to_delete in data["ID"].values:
        data = data[data["ID"] != id_to_delete]
        data.to_csv(file, index=False)
        print(" Sale deleted successfully!\n")
    else:
        print(" ID not found.\n")

# Main 
def menu():
    while True:
        print("1. Add Sale")
        print("2. Show Sales")
        print("3. Update Sale")
        print("4. Delete Sale")
        print("5. Exit")
        choice = input("Enter your choice (1-5): ")

        if choice == '1':
            add_sale()
        elif choice == '2':
            show_sales()
        elif choice == '3':
            update_sale()
        elif choice == '4':
            delete_sale()
        elif choice == '5':
            print(" Exit")
            break
        else:
            print(" Invalid choice. \n")


menu()
